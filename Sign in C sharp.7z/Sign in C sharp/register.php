<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register-Extremelab</title>
    <link rel="icon" href="logo1.png">

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <style media="screen">
        /* ... (Ihr vorhandener CSS-Stil) ... */
    </style>
</head>
<body>
    <img src="logo1.png" class="logo" alt="logo" style="mix-blend-mode: multiply;">
    <div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    <form method="post" action="">
        <h3>Register</h3>
        
        <label for="username">Username</label>
        <input type="text" placeholder="Email or Phone" id="username" name="username">

        <label for="password">Password</label>
        <input type="password" placeholder="Password" id="password" name="password">

        <button type="submit" name="register">Register</button>
        <div class="social">
          <div class="go"><i class="fab fa-google" style="cursor: pointer;"></i>  Google</div>
          <div class="fb"><i class="fab fa-facebook" style="cursor: pointer;"></i>  Facebook</div>
        </div>
    </form>

<?php
if(isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Verbindung zur Datenbank herstellen (Angaben anpassen)
    $servername = "id21169234_extremelab";
    $dbusername = "id21169234_mysite";
    $dbpassword = "Loli123?!";
    $dbname = "database_name";

    $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

    // Daten einfügen
    $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
    if ($conn->query($sql) === TRUE) {
        echo "Registration successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

</body>
</html>
