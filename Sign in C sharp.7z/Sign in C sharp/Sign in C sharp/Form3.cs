﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Diagnostics;

namespace Sign_in_C_sharp

{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string imagePath = @"C:\Users\vincent.hontscha\Desktop\Sign in C sharp\bg.png";

            if (System.IO.File.Exists(imagePath))
            {
                this.BackgroundImage = Image.FromFile(imagePath);
                this.BackgroundImageLayout = ImageLayout.Stretch;
            }
            else
            {
                MessageBox.Show("Error xf139");
            }

            int cornerRadius = 20;
            GraphicsPath path = new GraphicsPath();
            path.AddArc(0, 0, cornerRadius * 2, cornerRadius * 2, 180, 90);
            path.AddLine(cornerRadius, 0, pictureBox2.Width - cornerRadius, 0);
            path.AddArc(pictureBox2.Width - cornerRadius * 2, 0, cornerRadius * 2, cornerRadius * 2, 270, 90);
            path.AddLine(pictureBox2.Width, cornerRadius, pictureBox2.Width, pictureBox2.Height - cornerRadius);
            path.AddArc(pictureBox2.Width - cornerRadius * 2, pictureBox2.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 0, 90);
            path.AddLine(pictureBox2.Width - cornerRadius, pictureBox2.Height, cornerRadius, pictureBox2.Height);
            path.AddArc(0, pictureBox2.Height - cornerRadius * 2, cornerRadius * 2, cornerRadius * 2, 90, 90);
            path.AddLine(0, pictureBox2.Height - cornerRadius, 0, cornerRadius);
            path.CloseFigure();

            Region region = new Region(path);
            pictureBox2.Region = region;
            pictureBox2.Paint += new PaintEventHandler((paintSender, paintE) =>
            {
                using (Pen pen = new Pen(Color.Black, 3))
                {
                    paintE.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                    paintE.Graphics.DrawPath(pen, path);
                }
            });
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
        private void pictureBox7_Click_1(object sender, EventArgs e)
        {
            Form Form1 = new Form1();
            Form1.Show();

            this.Hide();
        }

        private void pictureBox5_Click_1(object sender, EventArgs e)
        {
            Form Form4 = new Form4();
            Form4.Show();
        }

        private void pictureBox20_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
